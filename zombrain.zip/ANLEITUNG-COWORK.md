# Anleitung für Claude Cowork: Zombrain online stellen

Cowork klickt auf deinem PC in GitHub für dich. Den Code lädt Claude Code hoch.
Kopiere die Teile **nacheinander** in Cowork.

Ablauf:

1. **Teil 1 in Cowork:** Das Repo wird angelegt.
2. **Claude Code „fertig“ schreiben:** Der Code wird hochgeladen.
3. **Teil 2 in Cowork:** Die Webseite wird eingeschaltet.
4. **Teil 3 in Cowork (optional):** Die App wird am PC installiert.

Voraussetzung: Du bist in Chrome bei GitHub als **jannes48** eingeloggt, und Cowork darf Chrome benutzen (Claude in Chrome).

---

## Teil 1: Repo anlegen

```text
Bitte leg in meinem GitHub-Konto ein neues Repository an. Benutze dafür Chrome, wo ich schon bei GitHub eingeloggt bin.

1. Öffne https://github.com/new
2. Owner: jannes48
3. Repository name: zombrain
4. Description: Meine private Screen-Time-App
5. Sichtbarkeit: Public
6. NICHTS ankreuzen: kein README, kein .gitignore, keine Lizenz. Das Repo muss komplett leer sein.
7. Klick auf „Create repository“.
8. Sag mir zum Schluss die Adresse des neuen Repos.

Regeln:
- Ändere sonst nichts in meinem GitHub-Konto.
- Wenn GitHub nach Passwort, Login oder 2-Faktor-Code fragt: Stopp und sag mir Bescheid. Gib nichts selbst ein.
- Wenn es „zombrain“ schon gibt: nichts löschen, nur Bescheid sagen.
```

➡️ Danach schreibst du Claude Code: **„fertig“**. Claude Code lädt dann den Code hoch.

> Falls Claude Code sagt, dass es keinen Zugriff auf das neue Repo hat: Auf
> https://github.com/settings/installations bei der **Claude**-App auf „Configure“
> klicken und `zombrain` freigeben (oder „All repositories“ wählen).

---

## Teil 2: Webseite einschalten (erst wenn der Code hochgeladen ist)

```text
Bitte schalte GitHub Pages für mein Repo jannes48/zombrain ein. Benutze Chrome.

1. Öffne https://github.com/jannes48/zombrain und prüfe, dass dort Dateien liegen (u. a. index.html). Wenn das Repo leer ist: Stopp und sag mir Bescheid.
2. Öffne https://github.com/jannes48/zombrain/settings/pages
3. Bei „Build and deployment“ → „Source“: „Deploy from a branch“ wählen.
4. Bei „Branch“: „main“ und Ordner „/ (root)“ wählen → „Save“.
5. Warte 1–2 Minuten und lade die Seite neu, bis oben steht: „Your site is live at https://jannes48.github.io/zombrain/“.
6. Öffne https://jannes48.github.io/zombrain/ und prüfe, ob ein rosa Gehirn mit „Hi! Ich bin dein Gehirn“ erscheint.
7. Sag mir, ob alles geklappt hat.

Regeln:
- Ändere keine anderen Einstellungen.
- Bei Passwort-, Login- oder Bezahl-Fragen: Stopp und Bescheid sagen.
```

---

## Teil 3 (optional): Am PC als App installieren

```text
Öffne https://jannes48.github.io/zombrain/ in Chrome.
Klick rechts in der Adressleiste auf das Installieren-Symbol (Bildschirm mit Pfeil / ⊕)
und dann auf „Installieren“. Sag mir, ob Zombrain jetzt als eigenes Fenster aufgeht.
```

---

## Handy (machst du selbst, Cowork kann nicht aufs Handy)

- **iPhone:** In **Safari** `jannes48.github.io/zombrain` öffnen → Teilen ⬆️ → **Zum Home-Bildschirm**.
  Falls der Schalter **„Als Web-App öffnen“** erscheint und du den Kurzbefehl nutzen willst, schalte ihn aus.
- **Android:** In **Chrome** öffnen → Menü ⋮ → **App installieren**.
- **Kurzbefehl für TikTok & Co.:** Die Anleitung steht in der App unter **Mehr**.
