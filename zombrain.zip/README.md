# 🧠 Zombrain

**Dein Gehirn verrottet, wenn du scrollst. Halte es fit!**

Zombrain ist eine kleine Web-App (PWA) für Handy, Tablet und PC. Sie hat ein süßes Gehirn, das zum Zombie wird, wenn du zu viel auf TikTok, Instagram & Co. hängst. Mit Fokus-Zeit, Detox und „Nein“-Sagen wird es wieder gesund.

> Privates Hobbyprojekt. Nicht verbunden mit anderen Screen-Time-Apps.
> Keine Werbung, kein Konto, kein Server. Alle Daten bleiben auf deinem Gerät.

## Was die App kann

- **🧠 Gehirn mit 5 Stufen:** Topfit → Okay → Müde → Matschig → Zombie (mit Fliegen und Würmern)
- **📱 Scroll-Timer:** „Ich scrolle jetzt“ starten, dann verrottet das Gehirn live
- **⚠️ Warnbildschirm:** Beim Öffnen von TikTok & Co. kommt die Frage „Willst du wirklich …?“ (per iPhone-Kurzbefehl)
- **🧘 Fokus & Detox:** Pomodoro-Timer, das Gehirn heilt (+1 % pro Minute, +5 % Bonus)
- **🌙 Zeitpläne:** Sperrzeiten wie Schlafenszeit oder Schule; in der Zeit ist der Warnbildschirm strenger
- **📊 Statistik:** 7-Tage-Diagramm, Serie unterm Limit, Verlauf
- **💾 Backup:** Export/Import als Datei; Hell- und Dunkelmodus; funktioniert offline

## Installieren

| Gerät | So geht's |
|---|---|
| iPhone/iPad | In **Safari** öffnen → Teilen ⬆️ → **Zum Home-Bildschirm** |
| Android | In **Chrome** öffnen → Menü ⋮ → **App installieren** |
| PC/Mac | In **Chrome/Edge** öffnen → Installieren-Symbol ⊕ in der Adressleiste |

## iPhone: Warnung beim Öffnen von TikTok

1. App **Kurzbefehle** → **Automation** → **＋** → **App**
2. App wählen (z. B. TikTok) → **Wird geöffnet**
3. **Nach Bestätigung ausführen** (sanft) oder **Sofort ausführen** (streng)
4. Aktion **URL öffnen** → `https://jannes48.github.io/zombrain/#/warn?app=TikTok`

Für jede App gibt es eine eigene Automation. Die fertigen Links findest du in der App unter **Mehr**.

**Tipp:** Das iPhone trennt die Daten von Safari und von Web-Apps auf dem Home-Bildschirm. Wenn dir beim „Zum Home-Bildschirm“ der Schalter **„Als Web-App öffnen“** angezeigt wird, schalte ihn aus. Dann nutzen Icon und Warnbildschirm dieselben Daten.

**Android:** Mit der App *MacroDroid* geht das genauso: Auslöser „App gestartet“ → Aktion „Webseite öffnen“.

## Grenzen

Eine Web-App darf die Bildschirmzeit nicht automatisch auslesen und andere Apps nicht sperren. Das dürfen nur Apple und Google. Zombrain zählt deshalb nur, was du selbst startest, und zeigt dir den Warnbildschirm.

## Technik

Reines HTML, CSS und JavaScript ohne Build-Schritt. Die Daten liegen im `localStorage`, ein Service Worker macht die App offline-fähig.

Lokal starten:

```bash
python3 -m http.server 8000
# dann http://localhost:8000 öffnen
```

| Datei | Inhalt |
|---|---|
| `js/brain.js` | Gehirn-Figur (SVG, 5 Stufen) |
| `js/store.js` | Speicher und Gehirn-Logik |
| `js/stats.js` | Diagramme |
| `js/app.js` | Screens und Router |
| `sw.js` | Offline-Cache |
